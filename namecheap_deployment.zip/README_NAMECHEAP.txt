=============================================================
S.E. VAULT UGANDA — NAMECHEAP CPANEL DEPLOYMENT GUIDE
=============================================================

This folder contains the complete, ready-to-deploy system:
- Frontend: Single Page Application (React 19 + Tailwind CSS)
- Backend: PHP REST API with MySQL database connection
- Database: shoplgkr_sevault.sql database schema
- Uploads: Pre-configured directory structure with images
- Server Config: .htaccess with Apache mod_rewrite for React Router

-------------------------------------------------------------
STEP 1: UPLOAD FILES TO NAMECHEAP
-------------------------------------------------------------
Option A (Recommended - Fastest):
1. Log into your Namecheap cPanel.
2. Open "File Manager" and navigate to "public_html".
3. Upload "namecheap_deployment.zip".
4. Right-click "namecheap_deployment.zip" and click "Extract".
5. Ensure the extracted files (index.html, .htaccess, api/, uploads/, assets/) 
   are placed directly in "public_html" (not inside a subfolder).

Option B:
Upload the contents of "namecheap_deployment" directly into public_html via FTP.

-------------------------------------------------------------
STEP 2: IMPORT THE DATABASE
-------------------------------------------------------------
1. In cPanel, navigate to "MySQL Databases".
2. Confirm the database and user exists:
   - Database Name: shoplgkr_sevault
   - Database User: shoplgkr_answerpats
   - User Password: 47[5#xMYZ&R~
   (If creating new credentials, update them in api/config.php)
3. Go back to cPanel and open "phpMyAdmin".
4. Select the "shoplgkr_sevault" database on the left.
5. Click the "Import" tab at the top.
6. Choose the file "shoplgkr_sevault.sql" and click "Go / Import".

-------------------------------------------------------------
STEP 3: VERIFY PERMISSIONS
-------------------------------------------------------------
1. In cPanel File Manager, ensure the "uploads" folder has 755 permissions
   so the PHP API can store uploaded images.
2. Ensure ".htaccess" is visible (in File Manager, click Settings -> Show Hidden Files).

-------------------------------------------------------------
YOUR SITE IS LIVE!
=============================================================
